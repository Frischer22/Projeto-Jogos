import pygame, random, time, os, sys
from pygame.locals import *
from images import *
x = 0
y = 0
width = 800
height = 800
position = 365
bgcolour = (255,255,0)

screen = pygame.display.set_mode((width,height))

random_virus = covid
random_person = doente
random_person2 = doente

pygame.init()
CLOCK = pygame.time.Clock()
pygame.display.set_caption("Subway-19!!!")

font = pygame.font.SysFont(None,40)
font1 = pygame.font.SysFont('monospace',30)
font2 = pygame.font.SysFont('monospace',25)
font3 = pygame.font.SysFont(None,70)
font4 = pygame.font.SysFont('monospace',40)
font5 = pygame.font.SysFont(None,60)


read=open("highscore.txt",'r')
topScore = float(read.readline())
read.close()

pygame.mixer.init()
swish = pygame.mixer.Sound("soundfiles/swish.ogg")

def buttons(xpos,ypos,colour,text,width,height):
    pygame.draw.rect(screen,colour,(xpos,ypos,width,height))
    msg = font.render(text,1,(0,0,0))
    screen.blit(msg,(xpos+25,ypos+12))
def start():
    pygame.mixer.music.load("soundfiles/menumusic.mp3")
    pygame.mixer.music.play(-1)
    while(1):
        screen.blit(bgimage,(0,0))
        screen.blit(logo,(0,10))
        label = font.render("Precione 'Enter' ou clique abaixo para iniciar!",1,(255,255,0))
        screen.blit(label,(130,470))
        buttons(270,530,(229,158,36),"Boa Sorte!!",200,60)
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if(270 < mouse[0] < 470 and 530 < mouse[1] < 590):
            buttons(270,530,(220,160,220),"Boa Sorte!!",200,60)
            if click[0] == 1:
                return 1
        pygame.display.update()
        command = pygame.event.poll()
        if(command.type == pygame.KEYDOWN):
            if(command.key == pygame.K_RETURN):
                return 1
        if command.type == pygame.QUIT:
                pygame.quit()
                quit()
def gameover():
        while(1):
            screen.blit(bgimage,(0,0))
            screen.blit(hospital,(0,50))
            label = font3.render("GAME OVER",1,(255,255,0))
            screen.blit(label,(250,480))
            label2 = font4.render("Jogar Novamente ???",1,(255,165,0))
            screen.blit(label2,(230,550))
            buttons(250,600,(0,150,0),"Sim",100,50)
            buttons(420,600,(150,0,0),"Sair",100,50)
            mouse = pygame.mouse.get_pos()
            click = pygame.mouse.get_pressed()
            if(250 < mouse[0] < 350 and 600 < mouse[1] < 650):
                buttons(250,600,(220,160,220),"Sim",100,50)
                if click[0] == 1:
                    return 1
            if(420 < mouse[0] < 520 and 600 < mouse[1] < 650):
                buttons(420,600,(220,160,220),"Sair",100,50)
                if click[0] == 1:
                    pygame.quit()
                    quit()
            pygame.display.update()
            command = pygame.event.poll()
            if command.type == pygame.QUIT:
                    pygame.quit()
                    quit()

def game_win():
        while(1):
            screen.blit(bgimage,(0,0))
            screen.blit(casa,(0,100))
            label = font5.render("Parabéns",1,(255,0,0))
            screen.blit(label,(300,380))
            label2 = font5.render("você chegou na sua casa",1,(255,0,0))
            screen.blit(label2,(180,450))
            label3 = font5.render("em segurança!",1,(255,0,0))
            screen.blit(label3,(250,520))
            label4 = font4.render("Jogar Novamente ???",1,(255,165,0))
            screen.blit(label4,(230,590))
            buttons(250,700,(0,150,0),"Sim",100,50)
            buttons(420,700,(150,0,0),"Sair",100,50)
            mouse = pygame.mouse.get_pos()
            click = pygame.mouse.get_pressed()
            if(250 < mouse[0] < 350 and 700 < mouse[1] < 750):
                buttons(250,700,(220,160,220),"Sim",100,50)
                if click[0] == 1:
                    return 1
            if(420 < mouse[0] < 520 and 700 < mouse[1] < 750):
                buttons(420,700,(220,160,220),"Sair",100,50)
                if click[0] == 1:
                    pygame.quit()
                    quit()
            pygame.display.update()
            command = pygame.event.poll()
            if command.type == pygame.QUIT:
                    pygame.quit()
                    quit()

start()
while(1):
    a = 0
    b = 0
    FPS_change = 0
    FPS = 40
    score = 0
    running = 1
    pygame.mixer.music.load("soundfiles/bgmusic.mp3")
    pygame.mixer.music.play(-1)
    position = 365
    obstacle_strategy = random.randint(0,6)
    while (running):
        w = 0
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        screen.fill(bgcolour)
        if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    if position == 615:
                        pygame.mixer.Sound.play(swish)
                        position = 115
                    else:
                        pygame.mixer.Sound.play(swish)
                        position = position + 250
                if event.key == pygame.K_LEFT:
                    if position == 115:
                        pygame.mixer.Sound.play(swish)
                        position = 615
                    else:
                        pygame.mixer.Sound.play(swish)
                        position = position - 250
        rel_y = y%road.get_rect().height
        screen.blit(road,(200,rel_y - road.get_rect().height))
        if(rel_y < height):
            screen.blit(road, (200,rel_y))
        screen.blit(grass,(10,rel_y - grass.get_rect().height))
        if(rel_y < height):
            screen.blit(grass, (10,rel_y))
        screen.blit(grass,(515,rel_y - grass.get_rect().height))
        if(rel_y < height):
            screen.blit(grass, (515,rel_y))
        y += 10
        screen.blit(bike,(position,500))
        if(obstacle_strategy == 0):
            screen.blit(random_person,(30,a-500))
            a += 10
            if(a > 1300):
                a = 0
                random_person = doente
                obstacle_strategy = random.randint(0,6)
            if(position == 115 and a-500 == 200):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 1):
            screen.blit(random_virus,(350,a-200))
            a += 15
            if(a > 900):
                a = 0
                random_virus = covid
                obstacle_strategy = random.randint(0,6)
            if(position == 365 and a-200 >= 310 and a-200 <= 550):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 2):
            screen.blit(random_person2,(550,a-500))
            a += 10
            if(a > 1300):
                a = 0
                random_person2 = doente
                obstacle_strategy = random.randint(0,6)
            if(position == 615 and a-500 == 200):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 3):
            screen.blit(random_person2,(550,a-500))
            screen.blit(random_person,(30,a-500))
            a += 10
            if(a > 1300):
                chek = 1
                a = 0
                random_person = doente
                random_person2 = doente
                obstacle_strategy = random.randint(0,6)
            if((position == 615 and a-500 == 200) or (position == 115 and a-500 == 200)):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 4):
            screen.blit(random_virus,(350,b-200))
            b += 15
            screen.blit(random_person,(30,a-500))
            a += 10
            if(a > 1300 and b > 900):
                a = 0
                b = 0
                random_person = doente
                random_virus = covid
                obstacle_strategy = random.randint(0,6)
            if((position == 365 and b-200 >= 310 and b-200 <= 550) or (position == 115 and a-500 == 200)):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 5):
            screen.blit(random_virus,(350,b-200))
            b += 15
            screen.blit(random_person2,(550,a-500))
            a += 10
            if(a > 1300 and b > 900):
                a = 0
                b = 0
                random_person2 = doente
                random_virus = covid
                obstacle_strategy = random.randint(0,6)
            if((position == 365 and b-200 >= 310 and b-200 <= 550) or (position == 615 and a-500 == 200)):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0

        if(obstacle_strategy == 6):
            screen.blit(random_virus,(350,b-200))
            b += 15
            screen.blit(random_person,(30,a-500))
            screen.blit(random_person2,(550,a-500))
            a += 10
            if(a > 1300 and b > 900):
                a = 0
                b = 0
                random_person = doente
                random_person2 = doente
                random_virus = covid
                obstacle_strategy = random.randint(0,6)
            if((position == 365 and b-200 >= 310 and b-200 <= 550) or ((position == 115 or position == 615) and a-500 == 200)):
                pygame.mixer.music.load("soundfiles/accident.mp3")
                pygame.mixer.music.play(1)
                running = 0
        score += 0.5
        score_value = font.render("Pontuação : "+str(score),1,(255,153,52))
        high_score = font.render("Meta: "+str(topScore),1,(255,153,52))
        screen.blit(score_value,(10,10))
        screen.blit(high_score,(10,40))
        pygame.display.update()
        FPS_change += 1
        if(FPS_change%200 == 0):
            FPS += 5
        CLOCK.tick(FPS)
        if score == topScore:
            game_win()
                
    gameover()
