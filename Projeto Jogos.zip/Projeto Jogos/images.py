import pygame

road = pygame.image.load("pictures/road.png")
road = pygame.transform.scale(road,(400,800))
grass = pygame.image.load("pictures/grass.jpg")
grass = pygame.transform.scale(grass,(275,800))

bike = pygame.image.load("pictures/bike1.png")
bike = pygame.transform.scale(bike,(70,140))

covid = pygame.image.load("pictures/covid19.png")
covid = pygame.transform.scale(covid,(120,240))
doente = pygame.image.load("pictures/pessoa_doente.png")
doente = pygame.transform.scale(doente,(204,408))

bgimage = pygame.image.load("pictures/Background1.jpg")
logo = pygame.image.load("pictures/logo.jpg")
logo = pygame.transform.scale(logo,(800,450))

casa = pygame.image.load("pictures/casa.jpg")
casa = pygame.transform.scale(casa,(920,400))

hospital = pygame.image.load("pictures/hospital.jpg")
hospital = pygame.transform.scale(hospital,(920,400))

